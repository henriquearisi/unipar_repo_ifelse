import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Cria um objeto Scanner para receber entrada do usuário
        Scanner scanner = new Scanner(System.in);

        // Solicita e lê o número inteiro
        System.out.println("Digite um número inteiro:");
        int numero = scanner.nextInt();

        // Fecha o Scanner após a leitura do número
        scanner.close();

        // Verifica se o número é par ou ímpar
        if (numero % 2 == 0) {
            System.out.println("O número digitado é par.");
        } else {
            System.out.println("O número digitado é ímpar.");
        }
    }
}
