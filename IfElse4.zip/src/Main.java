import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Cria um objeto Scanner para receber entrada do usuário
        Scanner scanner = new Scanner(System.in);

        // Solicita e lê o primeiro número inteiro
        System.out.println("Digite o primeiro número inteiro:");
        int numero1 = scanner.nextInt();

        // Solicita e lê o segundo número inteiro
        System.out.println("Digite o segundo número inteiro:");
        int numero2 = scanner.nextInt();

        // Fecha o Scanner após a leitura dos números
        scanner.close();

        // Verifica qual dos números é o maior
        if (numero1 > numero2) {
            System.out.println("O primeiro número (" + numero1 + ") é maior que o segundo número (" + numero2 + ").");
        } else if (numero2 > numero1) {
            System.out.println("O segundo número (" + numero2 + ") é maior que o primeiro número (" + numero1 + ").");
        } else {
            System.out.println("Os dois números são iguais.");
        }
    }
}
