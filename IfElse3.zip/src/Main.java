import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        // Definindo o nome de usuário e senha corretos
        String nomeUsuarioCorreto = "usuario";
        String senhaCorreta = "senha123";

        // Cria um objeto Scanner para receber entrada do usuário
        Scanner scanner = new Scanner(System.in);

        // Solicita e lê o nome de usuário
        System.out.println("Digite seu nome de usuário:");
        String nomeUsuario = scanner.nextLine();

        // Solicita e lê a senha
        System.out.println("Digite sua senha:");
        String senha = scanner.nextLine();

        // Fecha o Scanner após a leitura do nome de usuário e senha
        scanner.close();

        // Verifica se o nome de usuário e a senha estão corretos
        if (nomeUsuario.equals(nomeUsuarioCorreto) && senha.equals(senhaCorreta)) {
            System.out.println("Login bem-sucedido.");
        } else {
            System.out.println("Nome de usuário ou senha incorretos.");
        }
    }
}
